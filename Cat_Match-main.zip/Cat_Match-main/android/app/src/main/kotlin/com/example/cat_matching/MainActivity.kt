package com.example.cat_matching

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
