package com.example.pet_tinder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
