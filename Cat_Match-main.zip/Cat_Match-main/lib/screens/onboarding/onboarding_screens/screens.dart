export 'start_screen.dart';

export 'bio_screen.dart';
export 'details_screen.dart';
export 'email_screen.dart';
